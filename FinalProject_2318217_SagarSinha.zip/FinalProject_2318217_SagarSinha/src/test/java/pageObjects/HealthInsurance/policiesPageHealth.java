package pageObjects.HealthInsurance;

import actionPackage.actionClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

import java.util.List;

public class policiesPageHealth extends baseClass {
    public policiesPageHealth(){
        PageFactory.initElements(driver, this);
    }

    actionClass action = new actionClass();

    /* #Locators */
    @FindBy(xpath="//a[contains(text(),\"Insurance Products\")]")
    WebElement insuranceProduct;
    @FindBy(xpath="//a[@class='headlink' and contains(text(),'Health Insurance')]/following::ul[1]//a")
    List<WebElement> HealthInsuranceProducts;


    /* #Functions */
    // hovering on insurance products through navigation bar
    public void hoverHealthInsurance(){
        wait.until(ExpectedConditions.visibilityOf(insuranceProduct));
        action.hoverOnElement(driver, insuranceProduct);
    }

    // collecting data of products offered under health insurance on policybazar
    public void collectDataOfPlans(){
        System.out.println("----- Different Products of Health Insurance offered by https://www.policybazar.com/ -----");
        for(WebElement healthInsuranceProduct : HealthInsuranceProducts) {
            System.out.println(healthInsuranceProduct.getText());
        }
    }
}
