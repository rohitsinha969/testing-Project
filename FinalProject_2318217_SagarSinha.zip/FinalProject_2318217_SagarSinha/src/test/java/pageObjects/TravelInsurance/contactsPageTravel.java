package pageObjects.TravelInsurance;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import testBase.baseClass;

public class contactsPageTravel extends baseClass {

    public contactsPageTravel(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath = "//div[@class=\"custom-dropdown-floating-placeholder-inner \"]//input")
    WebElement phoneNumber;

    @FindBy(xpath = "//span[@class=\"slider round\"]")
    WebElement whatsappUpdates;

    @FindBy(xpath = "//button[@class=\"travel_main_cta\"]")
    WebElement viewPlans;

    @FindBy(xpath = "//span[@class=\"text-btn\"]")
    WebElement done;

    /* #Functions */
    public void sendPhoneNumber() {
        phoneNumber.sendKeys("9876543210");
    }

    public void toggleOff(){
        whatsappUpdates.click();
    }

    public void viewPlansForTravelInsurance(){
        viewPlans.click();
    }

    public void popupHandle(){
        done.click();
    }
}
