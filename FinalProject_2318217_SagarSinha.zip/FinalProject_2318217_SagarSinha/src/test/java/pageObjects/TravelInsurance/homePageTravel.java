package pageObjects.TravelInsurance;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

import java.time.Duration;

public class homePageTravel extends baseClass {
    public homePageTravel(){
        PageFactory.initElements(driver, this);
    }
    /* #Locators */
    @FindBy(xpath = "//div[@class=\"prd-block\"]//p[contains(text(),'Travel')]")
    WebElement travelInsuranceButton;

    /* #Functions */
    public void clickOnTravelInsurance() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(travelInsuranceButton));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", travelInsuranceButton);
    }

}
