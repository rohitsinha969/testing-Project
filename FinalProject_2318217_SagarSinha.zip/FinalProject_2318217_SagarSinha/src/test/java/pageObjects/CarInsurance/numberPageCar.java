package pageObjects.CarInsurance;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import testBase.baseClass;

public class numberPageCar extends baseClass {
    public numberPageCar(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath="//*[contains(@class,'input_box')]//input")
    WebElement searchCarNumber;
    @FindBy(xpath="//*[@id=\"btnSubmit\"]")
    public WebElement viewPriceBtn;


    /* #Functions */
    public void clear(){
        searchCarNumber.clear();
    }

    public void searchHelper(String number){
        searchCarNumber.sendKeys(number);
    }

    public void viewPrice(){
        viewPriceBtn.click();
    }
}
