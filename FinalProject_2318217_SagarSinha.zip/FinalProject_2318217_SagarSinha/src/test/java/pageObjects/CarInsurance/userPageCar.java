package pageObjects.CarInsurance;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import testBase.baseClass;

public class userPageCar extends baseClass {
    public userPageCar(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath="//input[@id=\"txtName\"]")
    WebElement inputUserName;
    @FindBy(xpath="//input[@id=\"txtEmail\"]")
    WebElement inputEmail;
    @FindBy(xpath="//input[@id=\"mobNumber\"]")
    WebElement inputPhoneNumber;
    @FindBy(xpath="//div[normalize-space()='View Prices']")
    WebElement viewPrices;
    @FindBy(xpath="//p[text()=\"No\"]")
    WebElement NoPlans;


    /* #Functions */
    // name inputs
    public void clearName(){
        inputUserName.clear();
    }

    public void sendName(String name){
        inputUserName.sendKeys(name);
    }

    // e-mail inputs
    public void clearEmail(){
        inputEmail.clear();
    }

    public void sendEmail(String email){
        inputEmail.sendKeys(email);
    }

    // phone number inputs
    public void clearPhone(){
        inputPhoneNumber.clear();
    }

    public void sendPhone(String phone){
        inputPhoneNumber.sendKeys(phone);
    }
}
