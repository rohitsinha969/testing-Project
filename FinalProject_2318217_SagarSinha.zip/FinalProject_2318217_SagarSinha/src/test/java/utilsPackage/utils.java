package utilsPackage;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.apache.commons.io.FileUtils;


import java.io.*;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;

public class utils {
    public void getScreenshot(WebDriver driver, String methodName){
        TakesScreenshot ts = (TakesScreenshot) driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        String filePath = "testOutput"+File.separator+"Screenshots"+File.separator+methodName+".jpeg";
        File destination = new File(filePath);
        try{
            FileUtils.copyFile(source,destination);
        } catch (IOException e) {
            System.out.println("Failed to capture screenshot for"+methodName);
        }
    }

    public void writeToExcel(String sheetName, String cellValue, int row, int col) throws IOException {
        String filePath = "testOutput"+ File.separator+"TestReports"+File.separator+"ProgramOutput.xlsx";
        File excelFile = new File(filePath);
        XSSFWorkbook workbook;

        if(excelFile.exists()){
            FileInputStream inputStr = new FileInputStream(excelFile);
            workbook = new XSSFWorkbook(inputStr);
            inputStr.close();
        }
        else{
            workbook = new XSSFWorkbook();
        }

        XSSFSheet sheet = workbook.getSheet(sheetName);
        if(sheet==null){
            sheet = workbook.createSheet(sheetName);
        }

        XSSFRow currentRow = sheet.getRow(row);
        if(currentRow==null){
            currentRow = sheet.createRow(row);
        }

        XSSFCell currentCell = currentRow.getCell(col);
        if(currentCell==null){
            currentCell = currentRow.createCell(col);
        }
        currentCell.setCellValue(cellValue);
        FileOutputStream outputStr = new FileOutputStream(excelFile);
        workbook.write(outputStr);
        outputStr.close();
    }

    public String parseJson(String fileName, String field) {
        JSONParser parser = new JSONParser();
        String fieldValue = null;
        try {
            Object obj = parser.parse(new FileReader(fileName));
            JSONObject jsonObject = (JSONObject) obj;
            fieldValue = (String) jsonObject.get(field);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fieldValue;
    }
}
