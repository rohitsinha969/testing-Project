package testBase;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.Browser;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import java.time.Duration;

public class baseClass {
    public static WebDriver driver;
    public static WebDriverWait wait;
    public static JavascriptExecutor js;

    @Parameters({"Browser"})
    @BeforeClass
    public static void setUpDriver(String Browser) {
        if(Browser.equals("chrome")){
            driver = new ChromeDriver();
        }
        else{
            System.out.println("Invalid Browser Requested...");
            System.exit(0);
        }

        // instantiating explicit wait
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

//        // instantiating js executor
//        js = (JavascriptExecutor)driver;

        // deleting previous cookies
        driver.manage().deleteAllCookies();

        // redirecting to "https://www.policybazar.com"
        driver.get("https://www.policybazaar.com/");

        // applying implicit wait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // maximizing the window
        driver.manage().window().maximize();
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }

}
