package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObjects.HealthInsurance.policiesPageHealth;
import testBase.baseClass;

public class tc_03_healthInsurance extends baseClass {

    /* #Page Objects */
    policiesPageHealth home = new policiesPageHealth();

    @BeforeClass
    public void objCreation() {
        home = new policiesPageHealth();
    }

    /* #Test Methods */
    @Test(priority = 1)
    public void visitHealthInsuranceTest(){
        home.hoverHealthInsurance();
    }

    @Test(priority = 2)
    public void collectData(){
        home.collectDataOfPlans();
    }
}
