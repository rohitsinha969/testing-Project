package testCases;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pageObjects.CarInsurance.insurancePlansPageCar;
import pageObjects.CarInsurance.numberPageCar;
import pageObjects.CarInsurance.homePageCar;
import pageObjects.CarInsurance.userPageCar;
import testBase.baseClass;

import java.util.HashSet;
import java.util.Set;

public class tc_02_carInsurance extends baseClass {
    private Set<String> errorDataSet = new HashSet<>();
    /* #Page Objects */
    homePageCar home = new homePageCar();
    numberPageCar carNumber = new numberPageCar();
    userPageCar user = new userPageCar();
    insurancePlansPageCar plan = new insurancePlansPageCar();

    @BeforeClass
    public void objCreation() {
        home = new homePageCar();
        carNumber = new numberPageCar();
        user = new userPageCar();
        plan = new insurancePlansPageCar();
    }

    /* #Test Methods */
    @Test(priority = 1)
    public void setUpPage() {
        home.visitCarInsurance();
    }


    @Test (priority = 2, dataProvider="number")
    public void searchUsingNumber(String number) {
        carNumber.clear();
        carNumber.searchHelper(number);
        carNumber.viewPrice();
        Actions action = new Actions(driver);
        action.keyDown(Keys.ENTER).perform();
        try {
            if(!errorDataSet.contains(home.errmsg.getText())) {
                System.out.println(home.errmsg.getText());
                errorDataSet.add(home.errmsg.getText());
            }

        }catch(Exception ignored) { }
    }

    @Test(priority=3, dataProvider = "inputName")
    public void validateInputName(String name) throws InterruptedException {
        user.clearName();
        user.sendName(name);
        Thread.sleep(2000);
        Actions action = new Actions(driver);
        action.keyDown(Keys.ENTER).perform();
        try {
            if(!errorDataSet.contains(home.errmsg.getText())) {
                System.out.println(home.errmsg.getText());
                errorDataSet.add(home.errmsg.getText());
            }

        }catch(Exception ignored) { }
    }


    @Test(priority=4, dataProvider = "inputEmail")
    public void validateInputEmail(String email) throws InterruptedException {
        user.clearEmail();
        user.sendEmail(email);
        Thread.sleep(2000);
        Actions action = new Actions(driver);
        action.keyDown(Keys.ENTER).perform();
        try {
            if(!errorDataSet.contains(home.errmsg.getText())) {
                System.out.println(home.errmsg.getText());
                errorDataSet.add(home.errmsg.getText());
            }

        }catch(Exception ignored) { }
    }


    @Test(priority=5, dataProvider = "inputPhoneNumber")
    public void validateInputPhNumber(String phoneNumber) throws InterruptedException {
        user.clearPhone();
        user.sendPhone(phoneNumber);
        Thread.sleep(2000);
        Actions action = new Actions(driver);
        action.keyDown(Keys.ENTER).perform();
        try {
            if(!errorDataSet.contains(home.errmsg.getText())) {
                System.out.println(home.errmsg.getText());
                errorDataSet.add(home.errmsg.getText());
            }

        }catch(Exception ignored) { }

        try {
            home.viewPrices.click();
        }
        catch(Exception ignored) { }
    }


    @Test(priority = 6)
    public void validateCarInsuranceWebPage() {
        home.validateCarInsurance();
    }
    // data provider
    @DataProvider(name="inputName")
    public Object[][] inputNames(){
        return new Object[][] {{" "},{"sagar1010"},{"Sagar"}};
    }
    @DataProvider (name="number")
    public Object[][] inputNumber(){
        return new Object[][] {{" "},{"MH12AZ00000"},{"MH12AZ1234"}};
    }
    @DataProvider (name="inputEmail")
    public Object[][] inputEmail(){
        return new Object[][] {{" "},{"sagar#google.cop"},{"Sagar@google.com"}};
    }
    @DataProvider (name="inputPhoneNumber")
    public Object[][] inputPhNumber(){
        return new Object[][] {{" "},{"12345"},{"0000000000"},{"9876543210"}};
    }

    @Test(priority = 7)
    public void titleValidation() throws InterruptedException {
        plan.titleAssertion();
    }
}
