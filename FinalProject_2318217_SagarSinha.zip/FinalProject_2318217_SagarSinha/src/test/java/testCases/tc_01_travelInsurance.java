package testCases;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObjects.TravelInsurance.*;
import testBase.baseClass;

public class tc_01_travelInsurance extends baseClass {

    /* #Page Objects */
    homePageTravel home = new homePageTravel();
    destinationPageTravel dest = new destinationPageTravel();
    tripDatesPageTravel date = new tripDatesPageTravel();
    travellersPageTravel people = new travellersPageTravel();
    medPageTravel med = new medPageTravel();
    contactsPageTravel contact = new contactsPageTravel();
    insurancePlansPageTravel ins = new insurancePlansPageTravel();
    insurancePlansFilterTravel filter = new insurancePlansFilterTravel();

    @BeforeClass
    public void objCreation() {
        home = new homePageTravel();
        dest = new destinationPageTravel();
        date = new tripDatesPageTravel();
        people = new travellersPageTravel();
        med = new medPageTravel();
        contact = new contactsPageTravel();
        ins = new insurancePlansPageTravel();
        filter = new insurancePlansFilterTravel();
    }

    /* #Test Methods */
    // test - travel insurance selection
    @Test(priority = 1)
    public void travelInsuranceSelection() throws InterruptedException {
        home.clickOnTravelInsurance();
    }

    // test - destination selection
    @Test(priority = 2)
    public void destinationSelection() throws InterruptedException {
        dest.selectDestinations();
    }

    // test - date selection
    @Test(priority = 3)
    public void dateSelection() throws InterruptedException {
        date.dateSelectFunction();
    }

    @Test(priority = 4)
    public void travellerSelection() throws InterruptedException {
        people.totalTravellers();
        people.traveller1Selection();
        people.traveller2Selection();
        people.proceedToMedPage();
    }

    @Test(priority = 5)
    public void medDetailSelection() throws InterruptedException {
        med.medSelection();
//        med.proceedToContacts();
    }

    @Test(priority = 6)
    public void contactsDetails() throws InterruptedException {
        Thread.sleep(2000);
        contact.sendPhoneNumber();
        contact.toggleOff();
        contact.viewPlansForTravelInsurance();
        contact.popupHandle();
    }

    @Test(priority = 7)
    public void insuranceDetailsPageHandling() throws InterruptedException {
//        ins.closePopUpWindow();
        ins.recommendedClose();
        ins.setStudentPlanType();
    }

    @Test(priority = 8)
    public void applyingStudentFilter() throws InterruptedException {
        filter.studentPlanFilter();
        filter.confirmBoxTravellerSelection();
        filter.durationConfirmation();
        System.out.println(filter.durationDescription());
        filter.applyFilter();
    }

    @Test(priority = 9)
    public void insurancePlansProcessing() throws InterruptedException {
        ins.sortLowToHigh();
//        ins.makeExtraPlansVisible();
        ins.planHeading();
        ins.planPrice();
        ins.planIssuingCompany();
    }

    @Test(priority = 10)
    public void navigateToHomePage(){
        ins.navigateToHome();
    }
}
