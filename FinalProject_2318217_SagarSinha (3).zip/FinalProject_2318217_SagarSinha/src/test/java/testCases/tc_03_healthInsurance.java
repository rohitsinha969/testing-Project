package testCases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObjects.HealthInsurance.policiesPageHealth;
import testBase.baseClass;

public class tc_03_healthInsurance extends baseClass {

    /* #Page Objects */
    policiesPageHealth home = new policiesPageHealth();

    @BeforeClass
    public void objCreation() {
        home = new policiesPageHealth();
    }

    /* #Test Methods */
    @Test(priority = 0)
    public void renderingURL(){
        navigateToURL();
    }

    // test - hover on health insurance
    @Test(priority = 1)
    public void visitHealthInsuranceTest(){
        home.hoverHealthInsurance();
    }

    // test - collect data of health insurance
    @Test(priority = 2, dependsOnMethods = "visitHealthInsuranceTest")
    public void collectData(){
        home.collectDataOfPlans();
    }

    // test - navigate back to home page
    @Test(priority = 3, dependsOnMethods = "collectData")
    public void navigateBackToHomePage(){
        navigateToHome();
    }
}
