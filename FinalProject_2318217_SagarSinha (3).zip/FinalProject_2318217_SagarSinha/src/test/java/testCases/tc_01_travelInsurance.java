package testCases;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObjects.TravelInsurance.*;
import testBase.baseClass;

public class tc_01_travelInsurance extends baseClass {

    /* #Page Objects */
    homePageTravel home = new homePageTravel();
    destinationPageTravel dest = new destinationPageTravel();
    tripDatesPageTravel date = new tripDatesPageTravel();
    travellersPageTravel people = new travellersPageTravel();
    medPageTravel med = new medPageTravel();
    contactsPageTravel contact = new contactsPageTravel();
    insurancePlansPageTravel ins = new insurancePlansPageTravel();
    insurancePlansFilterTravel filter = new insurancePlansFilterTravel();

    @BeforeClass
    public void objCreation() {
        home = new homePageTravel();
        dest = new destinationPageTravel();
        date = new tripDatesPageTravel();
        people = new travellersPageTravel();
        med = new medPageTravel();
        contact = new contactsPageTravel();
        ins = new insurancePlansPageTravel();
        filter = new insurancePlansFilterTravel();
    }

    /* #Test Methods */
    @Test(priority = 0)
    public void renderingURL(){
        navigateToURL();
    }


    // test - travel insurance selection
    @Test(priority = 1)
    public void travelInsuranceSelection() throws InterruptedException {
        home.clickOnTravelInsurance();
//        boolean status = home.checkErrorMessage();
//        Assert.assertTrue(status);
    }

    // test - destination selection
    @Test(priority = 2, dependsOnMethods = "travelInsuranceSelection")
    public void destinationSelection() throws InterruptedException {
        dest.selectDestinations();
    }

    // test - date selection
    @Test(priority = 3, dependsOnMethods = "destinationSelection")
    public void dateSelection() throws InterruptedException {
        date.dateSelectFunction();
    }

    // test - travellers selection
    @Test(priority = 4, dependsOnMethods = "dateSelection")
    public void travellerSelection() throws InterruptedException {
        people.totalTravellers();
        people.traveller1Selection();
        people.traveller2Selection();
        people.proceedToMedPage();
    }

    // test - medical details
    @Test(priority = 5, dependsOnMethods = "travellerSelection")
    public void medDetailSelection() throws InterruptedException {
        med.medSelection();
//        med.proceedToContacts();
    }

    // test - contact details
    @Test(priority = 6, dependsOnMethods = "medDetailSelection")
    public void contactsDetails() throws InterruptedException {
        Thread.sleep(2000);
        contact.sendPhoneNumber();
        contact.toggleOff();
        contact.viewPlansForTravelInsurance();
        contact.popupHandle();
    }

    // test - insurance details page
    @Test(priority = 7, dependsOnMethods = "contactsDetails")
    public void insuranceDetailsPageHandling() throws InterruptedException {
//        ins.closePopUpWindow();
        ins.recommendedClose();
        ins.setStudentPlanType();
    }

    // test - applying filters for travellers
    @Test(priority = 8, dependsOnMethods = "insuranceDetailsPageHandling")
    public void applyingStudentFilter() throws InterruptedException {
        filter.studentPlanFilter();
        filter.confirmBoxTravellerSelection();
        filter.durationConfirmation();
        System.out.println(filter.durationDescription());
        filter.applyFilter();
    }

    // test - final data retrieval
    @Test(priority = 9, dependsOnMethods = "applyingStudentFilter")
    public void insurancePlansProcessing() throws InterruptedException {
        ins.sortLowToHigh();
//        ins.makeExtraPlansVisible();
        ins.planHeading();
        ins.planPrice();
        ins.planIssuingCompany();
    }

    // test - navigate back to home page
    @Test(priority = 10, dependsOnMethods = "insurancePlansProcessing")
    public void navigateToHomePage(){
        navigateToHome();
    }
}
