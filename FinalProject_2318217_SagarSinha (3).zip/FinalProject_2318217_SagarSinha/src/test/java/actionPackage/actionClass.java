package actionPackage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import testBase.baseClass;

/*
 *   project
 *       |-> test
 *              |-> action package
 *                      |-> actionClass.java
 *
 *   Description : ▫️JS Executor functions setup - scrollToElement()
 *                 ▫️Action Class functions setup - hoverOnElement()
 *                 ▫️JS Executor functions setup - navigateToPage()
 * */

public class actionClass {
    public void scrollToElement(JavascriptExecutor jse, WebElement element){
        jse.executeScript("arguments[0].scrollIntoView({block : 'center'});", element);
    }

    public void hoverOnElement(WebDriver driver, WebElement element){
        Actions action = new Actions(driver);
        action.moveToElement(element).perform();
    }

//    public void hoverOnElement(WebElement element){
//        (new Actions(driver)).moveToElement(element).perform();
//    }

    public void navigateToPage(WebDriver driver, WebElement pageElement){
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        scrollToElement(jse, pageElement);
        jse.executeScript("arguments[0].click();", pageElement);
    }

    public boolean isEnabled(WebElement selectedElement){
        return selectedElement.isEnabled();
    }
//    public void enterKey(WebDriver driver,WebElement inputBox) {
//    	Actions action = new Actions(driver);
//    	action.keyDown();
//    }
}
