package reportManager;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import testBase.baseClass;
import utilsPackage.utils;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class extentReportManager extends baseClass implements ITestListener {
    utils utility = new utils();
//    public ExtentSparkReporter sparkReporter;
//    public ExtentReports extent;
//    public ExtentTest test;
//    String reportName;
//    static String screenShotPath = "testOutput"+ File.separator+"Screenshots"+File.separator;
//    public void onStart(ITestContext testContext) {
//        String timeStamp = new SimpleDateFormat("yyyy.MM.dd").format(new Date());// time stamp
//        reportName = "PolicyBazaar-Test-Report-" + timeStamp + ".html";
//        sparkReporter = new ExtentSparkReporter("testOutput"+ File.separator+"TestReports"+File.separator+ reportName);// specify location of the report
//        sparkReporter.config().setDocumentTitle("Policy Bazaar Test Report"); // Title of report
//        sparkReporter.config().setReportName("Policy Bazaar"); // name of the report
//        sparkReporter.config().setTheme(Theme.DARK);
//        extent = new ExtentReports();
//        extent.attachReporter(sparkReporter);
//        extent.setSystemInfo("Application", "Policy Bazaar");
//        extent.setSystemInfo("Module", "Hackathon Project");
//        extent.setSystemInfo("User Name", System.getProperty("user.name"));
//        extent.setSystemInfo("Environment", "QA");
////        String os = testContext.getCurrentXmlTest().getParameter("os");
////        extent.setSystemInfo("Operating System", os);
//        String browser = testContext.getCurrentXmlTest().getParameter("browser");
//        extent.setSystemInfo("Browser", "Chrome");
////			List<String> includedGroups = testContext.getCurrentXmlTest().getIncludedGroups();
////			if(!includedGroups.isEmpty()) {
////			extent.setSystemInfo("Groups", includedGroups.toString());
////			}
//    }
//
//    public void onTestSuccess(ITestResult result) {
//        test = extent.createTest(result.getTestClass().getName());
//        test.assignCategory(result.getMethod().getGroups()); // to display groups in report
//        test.log(Status.PASS,result.getName()+" got successfully executed");
//        utility.getScreenshot(driver,result.getName());
//        test.addScreenCaptureFromPath(screenShotPath+result.getName());
//    }
//
//    public void onTestFailure(ITestResult result) {
//        test = extent.createTest(result.getTestClass().getName());
//        test.assignCategory(result.getMethod().getGroups());
//        test.log(Status.FAIL,result.getName()+" got failed");
//        test.log(Status.INFO, result.getThrowable().getMessage());
//        utility.getScreenshot(driver,result.getName());
//        test.addScreenCaptureFromPath(screenShotPath+result.getName());
//    }
//
//    public void onTestSkipped(ITestResult result) {
//        test = extent.createTest(result.getTestClass().getName());
//        test.assignCategory(result.getMethod().getGroups());
//        test.log(Status.SKIP, result.getName()+" got skipped");
//        test.log(Status.INFO, result.getThrowable().getMessage());
//    }
//    public void onFinish(ITestContext testContext) {
//        extent.flush();
//        String pathOfExtentReport = "testOutput"+ File.separator+"TestReports"+File.separator+ reportName;
//        File extentReport = new File(pathOfExtentReport);
//        try {
//            Desktop.getDesktop().browse(extentReport.toURI());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }



    public ExtentSparkReporter sparkReporter;
    public ExtentReports extent;
    public ExtentTest test;
    String reportName;

    public static boolean errorMessage = false;

    static String screenShotPath = System.getProperty("user.dir")+File.separator+"Screenshots"+File.separator;
    public void onStart(ITestContext testContext) {
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd").format(new Date());
        String browser = testContext.getCurrentXmlTest().getParameter("browser");

        reportName = "PolicyBazaar-"+browser+"Test-Report-" + timeStamp + ".html";
        sparkReporter = new ExtentSparkReporter(System.getProperty("user.dir")+File.separator+"TestOutput"+File.separator+ reportName);
        sparkReporter.config().setDocumentTitle("Policy Bazaar Test Report");
        sparkReporter.config().setReportName("Policy Bazaar");
        sparkReporter.config().setTheme(Theme.DARK);
        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);

        extent.setSystemInfo("Application", "Policy Bazaar");
        extent.setSystemInfo("Module", "Hackathon Project");
        extent.setSystemInfo("User Name", System.getProperty("user.name"));
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("Browser", browser);
    }

    public void onTestSuccess(ITestResult result) {
        test = extent.createTest(result.getTestClass().getName());
        test.assignCategory(result.getMethod().getGroups());
        test.log(Status.PASS,result.getName()+" got successfully executed");
        if(errorMessage){
            utility.getScreenshot(driver, result.getName());
            test.addScreenCaptureFromPath(screenShotPath + result.getName()+".png");
        }
    }

    public void onTestFailure(ITestResult result) {
        test = extent.createTest(result.getTestClass().getName());
        test.assignCategory(result.getMethod().getGroups());
        test.log(Status.FAIL,result.getName()+" got failed");
        test.log(Status.INFO, result.getThrowable().getMessage());
        utility.getScreenshot(driver,result.getName());
        test.addScreenCaptureFromPath(screenShotPath+result.getName()+".png");
    }

    public void onTestSkipped(ITestResult result) {
        test = extent.createTest(result.getTestClass().getName());
        test.assignCategory(result.getMethod().getGroups());
        test.log(Status.SKIP, result.getName()+" got skipped");
        test.log(Status.INFO, result.getThrowable().getMessage());
    }
    public void onFinish(ITestContext testContext) {
        extent.flush();
        String pathOfExtentReport = System.getProperty("user.dir")+File.separator+"TestOutput"+File.separator+ reportName;
        File extentReport = new File(pathOfExtentReport);
        try {
            Desktop.getDesktop().browse(extentReport.toURI());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
