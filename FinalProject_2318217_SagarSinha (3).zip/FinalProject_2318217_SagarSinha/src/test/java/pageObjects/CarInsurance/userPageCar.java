package pageObjects.CarInsurance;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reportManager.extentReportManager;
import testBase.baseClass;
import utilsPackage.utils;

public class userPageCar extends baseClass {
    //    extentReportManager ExtentReportManager = new extentReportManager();
    utils utility = new utils();

    public userPageCar() {
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath = "//div[@class='err' and contains(text(),'Please enter')]")
    public WebElement errorMessage;
    @FindBy(xpath = "//input[@id=\"txtName\"]")
    WebElement inputUserName;
    @FindBy(xpath = "//input[@id=\"txtEmail\"]")
    WebElement inputEmail;
    @FindBy(xpath = "//input[@id=\"mobNumber\"]")
    WebElement inputPhoneNumber;
    @FindBy(xpath = "//div[normalize-space()='View Prices']")
    WebElement viewPrices;
    @FindBy(xpath = "//p[text()=\"No\"]")
    WebElement NoPlans;


    /* #Functions */
    public boolean getErrorMessage() {
        Actions action = new Actions(driver);
        action.keyDown(Keys.ENTER).perform();
        try {
            if (errorMessage.isDisplayed()) {
                extentReportManager.errorMessage = true;
                return true;
            } else {
                extentReportManager.errorMessage = false;
                return false;
            }
        } catch (Exception ignored) {
        }
        extentReportManager.errorMessage = false;
        return false;
    }

    public void fillApplicationDetails(String name, String email, String number) {
        inputUserName.clear();
        inputUserName.sendKeys(name);

        inputEmail.clear();
        inputEmail.sendKeys(email);

        inputPhoneNumber.clear();
        inputPhoneNumber.sendKeys(number);

        new Actions(driver).keyDown(Keys.ENTER).perform();
    }
    // name inputs
//    public void clearName(){
//        inputUserName.clear();
//    }
//
//    public void sendName(String name){
//        inputUserName.sendKeys(name);
//    }
//
//    // e-mail inputs
//    public void clearEmail(){
//        inputEmail.clear();
//    }
//
//    public void sendEmail(String email){
//        inputEmail.sendKeys(email);
//    }
//
//    // phone number inputs
//    public void clearPhone(){
//        inputPhoneNumber.clear();
//    }
//
//    public void sendPhone(String phone){
//        inputPhoneNumber.sendKeys(phone);
//    }
}
