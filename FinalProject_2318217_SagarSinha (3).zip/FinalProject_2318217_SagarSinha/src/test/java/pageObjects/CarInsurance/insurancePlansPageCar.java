package pageObjects.CarInsurance;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;
import testBase.baseClass;

import java.util.List;

public class insurancePlansPageCar extends baseClass {
    public insurancePlansPageCar(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
//    @FindBy(xpath = "//span[@class=\"btnContent\"]")
//    List<WebElement> prices;


    /* #Functions */
    public void titleAssertion() throws InterruptedException {
        Thread.sleep(10000);
        SoftAssert soft = new SoftAssert();
        String expectedTitle = driver.getTitle();
        String actualTitle = "Car Insurance";
        soft.assertEquals(expectedTitle, actualTitle, "Insurance Plan Page Title successfully asserted as \"True\"");
        soft.assertAll();
    }

}
