package pageObjects.TravelInsurance;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

import java.util.List;

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> destinationPage.java
 *
 *   Description : ▫️Locating elements on destination page to look for any European Country
 *                 ▫️handling input box and dropdowns to search "Germany"
 * */

public class destinationPageTravel extends baseClass {

    public destinationPageTravel(){
        PageFactory.initElements(driver, this);
    }
    /* #Locators */
    @FindBy(xpath = "//*[@id=\"country\"]")
    WebElement countryDropDown;

    @FindBy(xpath = "//button[@class=\"travel_main_cta\"]")
    WebElement destinationNextButton;

    /* #Functions */
    public void selectDestinations() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(countryDropDown));
        countryDropDown.click();
//        driver.findElement(By.xpath("//*[@id=\"country\"]")).click();
        driver.findElement(By.xpath("//div[@class='selectedCountryWrap']//input")).sendKeys("Germ");
        List<WebElement> locations = driver.findElements(By.xpath("//ul[@class='search-list']//li"));

        for(WebElement loc : locations){
            if(loc.getText().equals("Germany")){
                loc.click();
                break;
            }
        }

        wait.until(ExpectedConditions.visibilityOf(destinationNextButton));
        destinationNextButton.click();
//        driver.findElement(By.xpath("//button[@class=\"travel_main_cta\"]")).click();
    }
}
