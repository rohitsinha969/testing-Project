package pageObjects.TravelInsurance;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

import java.util.List;

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> medPage.java
 *
 *   Description : ▫️Locating elements on medical page to update pre-existing medical conditions of travellers
 *                 ▫️handling radioButtons to progress the search for plans
 * */


public class medPageTravel extends baseClass {
    public medPageTravel(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath = "//input[@id='ped_no']")
    WebElement medDetails;

    @FindBy(xpath = "//button[@class=\"travel_main_cta\"]")
    WebElement next;

    /* #Functions */
    public void medSelection() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(medDetails));
        medDetails.click();
    }

    public void proceedToContacts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(next));
        next.click();
    }
}
