package pageObjects.TravelInsurance;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> insurancePlansPage.java
 *
 *   Description : ▫️Locating elements on insurance page to find Travel Insurances
 *                 ▫️applying filters for student travellers by handling radioButtons for sorting prices in "low to high"
 * */


public class insurancePlansPageTravel extends baseClass {
    public insurancePlansPageTravel(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath = "//span[@class=\"exitIntentPopup__box__closePop\"]")
    WebElement popUp;

    @FindBy(xpath = "//i[@class=\"closeIconBtn\"]")
    WebElement recommended;

    @FindBy(xpath = "//li[@class='options_box_wrapper__option']//input[@id='studentTrip']")
    WebElement studentPlanType;

    @FindBy(xpath = "//div[@class=\"cardWrapper__showMore \"]")
    List<WebElement> viewMorePlans;

    @FindBy(xpath = "//p[@class=\"filter_name_heading\"]")
    WebElement sortDropdownArrow;

    @FindBy(xpath = "//input[@id=\"17_sort\"]")
    WebElement lowToHigh;

//    @FindBy(xpath = "//div[@class=\"quotesCard__planName\"]//p[2]")
//    List<WebElement> planHead;

    @FindBy(xpath = "//article[@class=\"row_wrap\"]//h1//a")
    WebElement homePage;


    /* #Functions */
    public void closePopUpWindow() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(popUp));
        popUp.click();
    }
    public void recommendedClose() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(recommended));
        recommended.click();
    }

    public void setStudentPlanType(){
        wait.until(ExpectedConditions.visibilityOf(studentPlanType));
        studentPlanType.click();
    }

    public void makeExtraPlansVisible() throws InterruptedException{
//        wait.until(ExpectedConditions.visibilityOf((WebElement) viewMorePlans));
        for(WebElement extra : viewMorePlans){
            extra.click();
        }
    }

    public void sortLowToHigh() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(sortDropdownArrow));
        Thread.sleep(5000);
        sortDropdownArrow.click();
        lowToHigh.click();
    }

    public void planHeading() throws InterruptedException {
        Thread.sleep(1000);
        ArrayList<WebElement> planHead = (ArrayList<WebElement>) driver.findElements(By.xpath("//div[@class=\"quotesCard__planName\"]//p[2]"));
        System.out.println("name of the plans...");
        for (WebElement el : planHead) { System.out.println(el.getText());}
    }

    public void planPrice() throws InterruptedException {
        Thread.sleep(1000);
        ArrayList<WebElement> planPrice = (ArrayList<WebElement>) driver.findElements(By.xpath("//span[@class=\"premiumPlanPrice\"]"));
        System.out.println("price of plans...");
        for (WebElement elPrice : planPrice) { System.out.println(elPrice.getText());}
    }

    public void planIssuingCompany() throws InterruptedException {
        Thread.sleep(1000);
        ArrayList<WebElement> planCompany = (ArrayList<WebElement>) driver.findElements(By.xpath("//p[@class=\"quotesCard--insurerName\"]"));
        System.out.println("issuing company of plans...");
        for (WebElement elCompany : planCompany) { System.out.println(elCompany.getText());}
    }

    public void navigateToHome(){
//        driver.navigate().to("https://www.policybazaar.com/");
        wait.until(ExpectedConditions.visibilityOf(homePage));
        homePage.click();
    }
}
