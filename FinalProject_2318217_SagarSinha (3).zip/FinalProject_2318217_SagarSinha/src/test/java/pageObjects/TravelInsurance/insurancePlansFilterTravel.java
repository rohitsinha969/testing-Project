package pageObjects.TravelInsurance;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import testBase.baseClass;

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> insurancePlansFilterPage.java
 *
 *   Description : ▫️Locating elements on insurance page to find Travel Insurances
 *                 ▫️applying filters for student travellers by handling dropdowns for both travellers
 * */


public class insurancePlansFilterTravel extends baseClass {
    public insurancePlansFilterTravel(){
        PageFactory.initElements(driver, this);
    }

    /* #Locators */
    @FindBy(xpath = "//input[@id=\"studentTrip\"]")
    WebElement studentFilterSelector1;

    @FindBy(xpath = "//input[@id=\"studentTrip\"]")
    WebElement studentFilterSelector2;

    @FindBy(xpath = "//input[@id=\"Traveller_1\"]")
    WebElement studentSelection1;

    @FindBy(xpath = "//input[@id=\"Traveller_2\"]")
    WebElement studentSelection2;

    @FindBy(xpath = "//select[@id=\"feet\"]")
    WebElement durationConfirmationDropdown;

    @FindBy(xpath = "//p[@class=\"travelDays\"]")
    WebElement durationDescriptionBox;

    @FindBy(xpath = "//button[contains(text(),\"Apply\")]")
    WebElement applyButton;

    /* #Functions */
    public void studentPlanFilter() throws InterruptedException {
//        wait.until(ExpectedConditions.elementToBeClickable(studentFilterSelector1));
//        wait.until(ExpectedConditions.elementToBeClickable(studentFilterSelector2));
//        Thread.sleep(2000);
//        studentFilterSelector1.click();
//        Thread.sleep(2000);
//        studentFilterSelector2.click();
        wait.until(ExpectedConditions.visibilityOf(studentFilterSelector1));
        wait.until(ExpectedConditions.visibilityOf(studentFilterSelector2));
        ((JavascriptExecutor)driver).executeScript("arguments[0].click();", studentFilterSelector1);
        ((JavascriptExecutor)driver).executeScript("arguments[0].click();", studentFilterSelector2);
    }

    public void confirmBoxTravellerSelection() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(studentSelection1));
        wait.until(ExpectedConditions.visibilityOf(studentSelection2));
        Thread.sleep(3000);
        studentSelection1.click();
        studentSelection2.click();
    }

    public void durationConfirmation(){
        wait.until(ExpectedConditions.visibilityOf(durationConfirmationDropdown));
        Select selectHelper = new Select(durationConfirmationDropdown);
        selectHelper.selectByVisibleText("30 Days");
    }

    public String durationDescription(){
        return durationDescriptionBox.getText();
    }

    public void applyFilter() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(applyButton));
        applyButton.click();
        Thread.sleep(3000);
    }
}
