package pageObjects.TravelInsurance;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import reportManager.extentReportManager;
import testBase.baseClass;

import java.time.Duration;/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> homePage.java
 *
 *   Description : ▫️Locating elements on homepage to find Travel Insurances
 *                 ▫️clickOnTravel() function to click the locator
 * */

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Travel Insurance
 *                                  |-> homePage.java
 *
 *   Description : ▫️Locating elements on home page to find Travel Insurances
 *                 ▫️clickOnTravel() function to click the locator
 * */


public class homePageTravel extends baseClass {
    public homePageTravel(){
        PageFactory.initElements(driver, this);
    }
    /* #Locators */
    @FindBy(xpath = "//div[@class=\"prd-block\"]//p[contains(text(),'Travel')]")
    WebElement travelInsuranceButton;

    @FindBy(xpath = "//*[@class='err' and @style='display: block;']")
    private WebElement errorMessage;

    /* #Functions */
    public void clickOnTravelInsurance() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOf(travelInsuranceButton));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)", "");
        js.executeScript("arguments[0].click();", travelInsuranceButton);
    }

}
