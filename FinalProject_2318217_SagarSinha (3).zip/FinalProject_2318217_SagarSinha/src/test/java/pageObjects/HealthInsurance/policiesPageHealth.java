package pageObjects.HealthInsurance;

import actionPackage.actionClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testBase.baseClass;

import java.util.List;

/*
 *   project
 *       |-> test
 *              |-> pageObjects package
 *                      |-> Health Insurance
 *                                  |-> policiesHomePage.java
 *
 *   Description : ▫️Locating elements on home page of policybazar to find the different products of health insurance offered by policybazar
 *                 ▫️hovering on insuranceProducts to search various healthInsuranceProducts
 *                 ▫️handling list of products to print each product detail on the console
 * */


public class policiesPageHealth extends baseClass {
    public policiesPageHealth(){
        PageFactory.initElements(driver, this);
    }

    actionClass action = new actionClass();

    /* #Locators */
    @FindBy(xpath="//a[contains(text(),\"Insurance Products\")]")
    WebElement insuranceProducts;
    @FindBy(xpath="//a[@class='headlink' and contains(text(),'Health Insurance')]/following::ul[1]//a")
    List<WebElement> healthInsuranceProducts;


    /* #Functions */
    // hovering on insurance products through navigation bar
    public void hoverHealthInsurance(){
        wait.until(ExpectedConditions.visibilityOf(insuranceProducts));
        action.hoverOnElement(driver, insuranceProducts);
    }

    // collecting data of products offered under health insurance on policybazar
    public void collectDataOfPlans(){
        System.out.println("----- Different Products of Health Insurance offered by https://www.policybazar.com/ -----");
        for(WebElement healthInsuranceProduct : healthInsuranceProducts) {
            System.out.println(healthInsuranceProduct.getText());
        }
    }
}
